from scrapy.item import Item, Field
from scrapy.loader import ItemLoader
from scrapy.loader.processors import TakeFirst


class SpiderItem(Item):
    title = Field()
    seotitle = Field()
    description = Field()
    url = Field()

class SpiderImage(Item):
    title = Field()
    image_urls = Field()
    images = Field()
    session_path = Field()

class SpiderItemLoader(ItemLoader):
    default_item_class = SpiderItem
    default_output_processor = TakeFirst()
