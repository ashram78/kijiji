# Scrapy settings for dirbot project

SPIDER_MODULES = ['dirbot.spiders']
NEWSPIDER_MODULE = 'dirbot.spiders'
DEFAULT_ITEM_CLASS = 'dirbot.items.SpiderItem'

ITEM_PIPELINES = {
    'dirbot.pipelines.RequiredFieldsPipeline' : 300,
    'dirbot.pipelines.FilterWordsPipeline' : 400,
    'dirbot.pipelines.MySQLStorePipeline' : 500,
    'scrapy.pipelines.images.ImagesPipeline': 600
}

MYSQL_HOST = 'localhost'
MYSQL_DBNAME = 'dirbot'
MYSQL_USER = 'root'
MYSQL_PASSWD = 'goldtree85'

DOWNLOAD_DELAY = 3.0
AUTOTHROTTLE_ENABLED = True
AUTOTHROTTLE_START_DELAY = 1
AUTOTHROTTLE_MAX_DELAY = 3
IMAGES_STORE = '/var/www/html/adsos/scrapy/images'
