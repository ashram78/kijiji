from scrapy.spiders import Spider, Rule
from scrapy.selector import Selector
from dirbot.items import SpiderItem, SpiderItemLoader, SpiderImage
from hashlib import md5
import scrapy
import re
import datetime


class Kijiji(Spider):
    name = "kijiji"
    allowed_domains = ["kijiji.it", "annuncicdn.it"]
    start_urls = [
        "http://www.kijiji.it/annunci/?entryPoint=sb"
    ]
#    custom_settings = {'IMAGES_STORE': '/var/www/html/adsos/scrapy/images/'}
    
    def parse(self, response):
    
        hxs = Selector(response)
        ads = hxs.xpath('//div[@class="item-content"]')
        
        for (i, ad) in enumerate(ads):
            item = SpiderItem()
            item['title'] = ad.xpath('//h3[@class="title"]/text()').extract()[i].strip()
            item['seotitle'] = self.getSeotitle(item['title'])
            item['url'] = ad.css('a[class=cta]::attr(href)').extract()[0]
            if ad.xpath('//p[contains(@class,"description")]/text()'):
                item['description'] = ad.xpath('//p[contains(@class,"description")]/text()').extract()[i].strip()
            else:
                item['description'] = ''
            yield item
        
        ads = hxs.xpath('//li[@class="item result"]')
        
        for (i, ad) in enumerate(ads):
            item = SpiderImage()
            img_url = ad.xpath('//p[@class="thumbnail"]/img/@src').extract()[i]
            images = ['http:' + str(img_url)]
            title = ad.xpath('//h3[@class="title"]/text()').extract()[i].strip()
            today = datetime.date.today()
            now = today.strftime('%Y/%m/%d')
            yield {
                'image_urls': images,
                'title': title,
                'session_path': now
            }
        
    def getSeotitle(self, title):
        
        title = title.strip()
        title = title.lower()
        title = re.sub('\s', '-', title)
        title = re.sub('\-+', '-', title)
        title = re.sub('[^a-z0-9\-]', '', title)
        return title
    
        
        
